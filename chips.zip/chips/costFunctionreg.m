function [J,grad]= costFunctionreg(theta,X,y, lambda)
m= length(y);
n= size(theta);

j=0;
grad=zeros(n);

h=sigmoid(X*theta);
theta(1)=0;

J = (1/m)*sum(-y.*log(h) .-(1.-y).*log(1.-h)) + ((lambda/(2*m))*sum(theta.^2));
grad = (1/m)* (X'*(h .- y) + lambda*theta);

end