function j = computeCostmult(X,y,theta)

m=length(y);

j=(1/(2*m)* sum((X*theta - y).^2));
%j=(1/(2*m)) * (X * theta - y)' * (X * theta - y);
end
