function  X = featureNormaliza(X)
X_norm= X;
mu = zeros(1,size(X,2));
sigma =zeros(1, size(X,2));

%for i=1:size(X,2)
 % mu(i) = mean (X(:,i));
  %X_norm(:,i) = X_norm(:,i) - mu(i);
%  X_norm(:,i) = X_norm(:,i) / sigma(i);
%end

mu = mean(X_norm);
sigma = std(X_norm);
m = size(X,1)
X_norm=(X-(ones(m,1)*mu)) ./ (ones(m,1)*sigma);
end