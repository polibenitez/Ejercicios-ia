function [theta,j] = gradientDescentmult(X,y,theta,alpha,num_iters)

m=length(y);
j=zeros(num_iters,1);
h= X*theta;
for iter= 1:num_iters

 theta -= (alpha/m)* (X'*(h-y));
 j(iter)=computeCostmult(X,y,theta);
end
end 