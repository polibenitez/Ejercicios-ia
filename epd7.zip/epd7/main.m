%% EPD 6: Machine Learning – Regresión

%% Initialization
clear ; close all; clc

%% ======================= EJ1. Cargar y visualizar =======================

fprintf('Loading Data ...\n')

data = load('ex1data2.txt');
% de esta
X = data(:, 1:2);
y = data(:, 3);
m = length(y);

% Print out some data points
fprintf('First 10 examples from the dataset: \n');
fprintf(' x = [%.0f %.0f], y = %.0f \n', [X(1:10,:) y(1:10,:)]');

fprintf('Normalizing Features ...\n');
X= featureNormalize(X);
X = [ones(m,1),X];

fprintf('Compute cost features...');

theta=zeros(3,1);
[theta,j] =gradientDescentmult(X,y,theta,0.03,200);

%plot(1:200,j);
figure;
plot(1:200,j);
xlabel('Number of iterations');
ylabel('Cost J');

% Display gradient descent's result
fprintf('Theta computed from gradient descent: \n');
fprintf(' %f \n', theta);
fprintf('\n');


%prob = sigmoid([1650 3 2] * theta);
newhouse= [1650 3];
newhouse_norm= (newhouse-mu)./sigma;
performance= theta' *[1;newhouse_norm'];
fprintf(['Predicted price of a 1650 sq-ft, 3 br house ' ...
         '(using gradient descent):\n $%f\n'], performance);

% Compute accuracy on our training set
p = predict(theta, X);

fprintf('Train Accuracy: %f\n', mean(double(p == y)) * 100);
